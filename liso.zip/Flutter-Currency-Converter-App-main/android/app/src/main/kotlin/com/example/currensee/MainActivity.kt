package com.liso.converter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
