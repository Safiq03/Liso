class SliderModal{
  String? title;
  String? author;
  String? urlToImage;
  String? url;
  SliderModal({
    this.title,
    this.author,
    this.urlToImage,
    this.url
});
}